﻿Group 25

JAEYEONG KO
* CS ID: jaeyeong
* NetID: jko26@wisc.edu
YeEun Lim
* CS ID: yeeun 
* NetID: ylim52@wisc.edu
Sung Jin Park
* CS ID: sungp
* Net ID: spark288@wisc.edu


In Sample.java, there is the instructions to run the application(Use command 'help'). 
Also, I includedthe result of sampling 10 rows from each of the tables in part A in Sample results.txt.